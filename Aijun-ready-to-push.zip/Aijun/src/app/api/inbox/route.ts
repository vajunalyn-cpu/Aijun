import { NextRequest, NextResponse } from "next/server";
import { listInbox } from "@/lib/google";
import { fail, googleToken } from "@/lib/http";
import { triage } from "@/lib/triage";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function GET(req: NextRequest) {
  try {
    const token = await googleToken(req);
    const items = await triage(await listInbox(token, 20));
    return NextResponse.json({ items });
  } catch (err) {
    return fail(err);
  }
}

import { NextRequest, NextResponse } from "next/server";
import { archiveMessage } from "@/lib/google";
import { fail, googleToken, HttpError } from "@/lib/http";

export async function POST(req: NextRequest) {
  try {
    const token = await googleToken(req);
    const { messageId } = await req.json();
    if (!messageId) throw new HttpError("Missing message.", 400);
    await archiveMessage(token, String(messageId));
    return NextResponse.json({ ok: true });
  } catch (err) {
    return fail(err);
  }
}

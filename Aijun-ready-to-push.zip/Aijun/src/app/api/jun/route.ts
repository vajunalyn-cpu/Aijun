import { NextRequest, NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import { getTimeZone } from "@/lib/google";
import { fail, googleToken, HttpError } from "@/lib/http";
import { askJun, type ChatTurn } from "@/lib/jun";
import { readPrefs } from "@/lib/schedule";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/** POST { history: ChatTurn[], prefs: { origin, buffer, mode } } → { reply, changed } */
export async function POST(req: NextRequest) {
  try {
    const token = await googleToken(req);
    const body = await req.json();
    const history = (Array.isArray(body.history) ? body.history : [])
      .filter((t: ChatTurn) => (t.role === "user" || t.role === "assistant") && typeof t.content === "string")
      .map((t: ChatTurn) => ({ role: t.role, content: t.content.slice(0, 4000) })) as ChatTurn[];
    if (!history.length || history.at(-1)?.role !== "user") throw new HttpError("Say something to Jun first.", 400);

    const [tz, jwt] = await Promise.all([
      getTimeZone(token),
      getToken({ req, secret: process.env.NEXTAUTH_SECRET }),
    ]);
    const result = await askJun({
      token,
      tz,
      prefs: readPrefs(body.prefs ?? {}),
      history,
      userName: jwt?.name ?? undefined,
    });
    return NextResponse.json(result);
  } catch (err) {
    return fail(err);
  }
}

import { NextRequest, NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import { getTimeZone, listEvents } from "@/lib/google";
import { fail, googleToken } from "@/lib/http";
import { mapsConfigured } from "@/lib/maps";
import { brief, enrich, localMidnight, localParts, readPrefs } from "@/lib/schedule";

export const dynamic = "force-dynamic";

/** GET /api/schedule?days=2&origin=...&buffer=10&mode=DRIVE */
export async function GET(req: NextRequest) {
  try {
    const token = await googleToken(req);
    const params = req.nextUrl.searchParams;
    const days = Math.min(14, Math.max(1, Number(params.get("days") ?? 2)));
    const prefs = readPrefs(params);
    const tz = await getTimeZone(token);
    const from = localMidnight(localParts(Date.now(), tz).ymd, tz);
    const to = new Date(from.getTime() + days * 86400000);
    const events = await enrich(await listEvents(token, from, to), prefs, tz);
    const jwt = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
    return NextResponse.json({
      timeZone: tz,
      events,
      brief: brief(events, tz, jwt?.name ?? undefined),
      mapsReady: mapsConfigured(),
    });
  } catch (err) {
    return fail(err);
  }
}

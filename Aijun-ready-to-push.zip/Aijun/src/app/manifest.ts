import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Jun, your executive assistant",
    short_name: "Jun",
    description: "Calendar, travel and inbox, handled. Talk or type.",
    start_url: "/",
    display: "standalone",
    background_color: "#edf1ee",
    theme_color: "#12302a",
    icons: [{ src: "/icon.svg", sizes: "any", type: "image/svg+xml" }],
  };
}

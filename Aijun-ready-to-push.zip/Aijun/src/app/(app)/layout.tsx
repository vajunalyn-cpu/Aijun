import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { AppShell } from "@/components/AppShell";
import { SignIn } from "@/components/SignIn";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);
  if (!session?.user || session.error === "RefreshError") return <SignIn />;
  return (
    <AppShell user={{ name: session.user.name, email: session.user.email, image: session.user.image }}>
      {children}
    </AppShell>
  );
}

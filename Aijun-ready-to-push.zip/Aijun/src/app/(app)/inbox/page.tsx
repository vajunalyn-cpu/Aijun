import type { Metadata } from "next";
import { InboxView } from "@/components/InboxView";

export const metadata: Metadata = { title: "Inbox, Jun" };

export default function InboxPage() {
  return <InboxView />;
}

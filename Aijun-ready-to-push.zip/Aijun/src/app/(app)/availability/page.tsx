import type { Metadata } from "next";
import { AvailabilityView } from "@/components/AvailabilityView";

export const metadata: Metadata = { title: "Availability, Jun" };

export default function AvailabilityPage() {
  return <AvailabilityView />;
}

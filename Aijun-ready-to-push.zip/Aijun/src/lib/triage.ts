import Anthropic from "@anthropic-ai/sdk";
import type { MailItem } from "./google";

export type Bucket = "needs_you" | "can_wait" | "fyi";
export type TriagedMail = MailItem & { bucket: Bucket; summary: string; suggestedReply?: string };

const NOREPLY = /no-?reply|notifications?@|newsletter|mailer|updates@|news@|digest/i;

function heuristic(items: MailItem[]): TriagedMail[] {
  return items.map((m) => {
    const text = `${m.subject} ${m.snippet}`;
    const bucket: Bucket = NOREPLY.test(m.fromEmail)
      ? "fyi"
      : /\?|urgent|asap|deadline|today|tomorrow|confirm|approve|meeting|invite/i.test(text)
        ? "needs_you"
        : "can_wait";
    return { ...m, bucket, summary: m.snippet.slice(0, 110) };
  });
}

/** Sorts mail into Needs you / Can wait / FYI with a one-line summary each. Falls back to simple rules. */
export async function triage(items: MailItem[]): Promise<TriagedMail[]> {
  if (!items.length) return [];
  if (!process.env.ANTHROPIC_API_KEY) return heuristic(items);
  try {
    const client = new Anthropic();
    const res = await client.messages.create({
      model: process.env.ANTHROPIC_FAST_MODEL || "claude-haiku-5-5",
      max_tokens: 2000,
      system:
        'You triage an executive\'s inbox. Return ONLY a JSON array, no prose, no code fences. Each item: {"id": string, "bucket": "needs_you"|"can_wait"|"fyi", "summary": string (max 14 words, plain), "suggestedReply": string (only for needs_you: a short, warm, decisive reply body with no greeting line or signature)}. needs_you = a real person waiting on a decision, answer or action. can_wait = personal or work mail without urgency. fyi = automated, receipts, newsletters, notifications.',
      messages: [
        {
          role: "user",
          content: JSON.stringify(
            items.map(({ id, from, fromEmail, subject, snippet }) => ({ id, from, fromEmail, subject, snippet })),
          ),
        },
      ],
    });
    const text = res.content
      .filter((b): b is Anthropic.TextBlock => b.type === "text")
      .map((b) => b.text)
      .join("")
      .replace(/```json|```/g, "")
      .trim();
    const parsed = JSON.parse(text) as { id: string; bucket: Bucket; summary: string; suggestedReply?: string }[];
    const byId = new Map(parsed.map((p) => [p.id, p]));
    const fallback = heuristic(items);
    return items.map((m, i) => {
      const p = byId.get(m.id);
      if (!p || !["needs_you", "can_wait", "fyi"].includes(p.bucket)) return fallback[i];
      return { ...m, bucket: p.bucket, summary: p.summary || m.snippet.slice(0, 110), suggestedReply: p.suggestedReply };
    });
  } catch (err) {
    console.warn("Triage fell back to rules", err);
    return heuristic(items);
  }
}

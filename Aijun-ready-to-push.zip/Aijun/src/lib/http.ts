import { NextRequest, NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import { refreshGoogleToken } from "./auth";

export class HttpError extends Error {
  constructor(message: string, public status = 500) {
    super(message);
  }
}

/** Returns a valid Google access token for the signed-in user, refreshing it if needed. */
export async function googleToken(req: NextRequest): Promise<string> {
  let token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  if (!token?.accessToken) throw new HttpError("Sign in with Google to continue.", 401);
  if (!token.expiresAt || Date.now() / 1000 >= token.expiresAt - 60) {
    try {
      token = await refreshGoogleToken(token);
    } catch {
      throw new HttpError("Your Google session expired. Sign in again.", 401);
    }
  }
  return token.accessToken as string;
}

export function fail(err: unknown) {
  const status = err instanceof HttpError ? err.status : (err as { status?: number })?.status ?? 500;
  const message = err instanceof Error ? err.message : "Something went wrong.";
  if (status >= 500) console.error(err);
  return NextResponse.json({ error: message }, { status });
}

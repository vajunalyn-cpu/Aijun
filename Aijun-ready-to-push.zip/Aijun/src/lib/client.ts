"use client";

export type Verdict = "in_person" | "consider_online" | "take_online" | "online" | "no_location";

export type DayEvent = {
  id: string;
  title: string;
  start: string;
  end: string;
  allDay: boolean;
  location: string | null;
  meetLink?: string;
  online: boolean;
  attendees: number;
  organizerSelf: boolean;
  htmlLink?: string;
  isBlock: boolean;
  directionsUrl?: string;
  advice: {
    verdict: Verdict;
    reason: string;
    travelMinutes?: number;
    distanceKm?: number;
    leaveBy?: string;
    origin?: string;
  } | null;
};

export type Settings = {
  homeBase: string;
  mode: "DRIVE" | "TRANSIT" | "WALK" | "TWO_WHEELER";
  bufferMinutes: number;
  speakReplies: boolean;
  voiceLang: string;
  alertMinutes: number;
};

export const DEFAULT_SETTINGS: Settings = {
  homeBase: "",
  mode: "DRIVE",
  bufferMinutes: 10,
  speakReplies: true,
  voiceLang: "en-US",
  alertMinutes: 10,
};

export async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.error ?? `Request failed (${res.status})`);
  return data as T;
}

export function prefsQuery(s: Settings) {
  const p = new URLSearchParams({ buffer: String(s.bufferMinutes), mode: s.mode });
  if (s.homeBase) p.set("origin", s.homeBase);
  return p;
}

export function fmtTime(iso: string, tz?: string) {
  return new Intl.DateTimeFormat(undefined, { hour: "numeric", minute: "2-digit", timeZone: tz }).format(new Date(iso));
}

export function fmtDay(iso: string, tz?: string) {
  return new Intl.DateTimeFormat(undefined, { weekday: "long", month: "long", day: "numeric", timeZone: tz }).format(
    new Date(iso),
  );
}

export function dayKey(iso: string | number, tz?: string) {
  return new Intl.DateTimeFormat("en-CA", { year: "numeric", month: "2-digit", day: "2-digit", timeZone: tz }).format(
    new Date(iso),
  );
}

export function minutesBetween(a: string, b: string) {
  return Math.round((Date.parse(b) - Date.parse(a)) / 60000);
}

export const VERDICT_LABEL: Record<Verdict, string> = {
  in_person: "Go in person",
  consider_online: "Consider online",
  take_online: "Take it online",
  online: "Online",
  no_location: "No travel plan",
};

import { HttpError } from "./http";

const CAL = "https://www.googleapis.com/calendar/v3";
const GMAIL = "https://gmail.googleapis.com/gmail/v1/users/me";

async function g<T>(token: string, url: string, init: RequestInit = {}): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      ...(init.headers ?? {}),
    },
    cache: "no-store",
  });
  if (res.status === 204) return undefined as T;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = data?.error?.message ?? `Google request failed (${res.status})`;
    throw new HttpError(msg, res.status === 401 ? 401 : res.status);
  }
  return data as T;
}

/* ───────────── Calendar ───────────── */

export type CalEvent = {
  id: string;
  status?: string;
  summary?: string;
  description?: string;
  location?: string;
  htmlLink?: string;
  hangoutLink?: string;
  transparency?: string;
  start: { dateTime?: string; date?: string; timeZone?: string };
  end: { dateTime?: string; date?: string; timeZone?: string };
  attendees?: { email: string; self?: boolean; organizer?: boolean; responseStatus?: string; displayName?: string }[];
  organizer?: { email?: string; self?: boolean };
  conferenceData?: { entryPoints?: { entryPointType?: string; uri?: string }[] };
  extendedProperties?: { private?: Record<string, string> };
};

export async function getTimeZone(token: string): Promise<string> {
  try {
    const d = await g<{ value: string }>(token, `${CAL}/users/me/settings/timezone`);
    return d.value || "UTC";
  } catch {
    return "UTC";
  }
}

export async function listEvents(token: string, timeMin: Date, timeMax: Date): Promise<CalEvent[]> {
  const p = new URLSearchParams({
    timeMin: timeMin.toISOString(),
    timeMax: timeMax.toISOString(),
    singleEvents: "true",
    orderBy: "startTime",
    maxResults: "100",
  });
  const d = await g<{ items?: CalEvent[] }>(token, `${CAL}/calendars/primary/events?${p}`);
  return (d.items ?? []).filter((e) => e.status !== "cancelled");
}

export async function getEvent(token: string, id: string) {
  return g<CalEvent>(token, `${CAL}/calendars/primary/events/${encodeURIComponent(id)}`);
}

export async function listBlocks(token: string): Promise<CalEvent[]> {
  const now = new Date();
  const p = new URLSearchParams({
    timeMin: new Date(now.getTime() - 86400000).toISOString(),
    timeMax: new Date(now.getTime() + 365 * 86400000).toISOString(),
    singleEvents: "true",
    orderBy: "startTime",
    privateExtendedProperty: "jun=block",
  });
  const d = await g<{ items?: CalEvent[] }>(token, `${CAL}/calendars/primary/events?${p}`);
  return d.items ?? [];
}

function addDays(ymd: string, days: number) {
  const d = new Date(`${ymd}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

/** Blocks whole days (inclusive) as busy so nobody can book you. */
export async function createBlock(token: string, startDate: string, endDate: string, reason: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(startDate) || !/^\d{4}-\d{2}-\d{2}$/.test(endDate)) {
    throw new HttpError("Dates must look like 2026-11-20.", 400);
  }
  if (endDate < startDate) throw new HttpError("The end date is before the start date.", 400);
  return g<CalEvent>(token, `${CAL}/calendars/primary/events`, {
    method: "POST",
    body: JSON.stringify({
      summary: reason ? `Unavailable: ${reason}` : "Unavailable",
      description: "Blocked by Jun. Remove it from Jun to free these dates.",
      start: { date: startDate },
      end: { date: addDays(endDate, 1) },
      transparency: "opaque",
      colorId: "8",
      extendedProperties: { private: { jun: "block" } },
    }),
  });
}

export async function deleteEvent(token: string, id: string) {
  await g(token, `${CAL}/calendars/primary/events/${encodeURIComponent(id)}?sendUpdates=all`, { method: "DELETE" });
}

export async function moveEvent(token: string, id: string, start: Date, end: Date) {
  return g<CalEvent>(token, `${CAL}/calendars/primary/events/${encodeURIComponent(id)}?sendUpdates=all`, {
    method: "PATCH",
    body: JSON.stringify({ start: { dateTime: start.toISOString() }, end: { dateTime: end.toISOString() } }),
  });
}

export async function makeOnline(token: string, id: string) {
  return g<CalEvent>(
    token,
    `${CAL}/calendars/primary/events/${encodeURIComponent(id)}?conferenceDataVersion=1&sendUpdates=all`,
    {
      method: "PATCH",
      body: JSON.stringify({
        location: "",
        conferenceData: {
          createRequest: { requestId: crypto.randomUUID(), conferenceSolutionKey: { type: "hangoutsMeet" } },
        },
      }),
    },
  );
}

export async function freeBusy(token: string, timeMin: Date, timeMax: Date, emails: string[] = []) {
  const ids = ["primary", ...emails.filter(Boolean)].slice(0, 20);
  const d = await g<{ calendars: Record<string, { busy?: { start: string; end: string }[] }> }>(token, `${CAL}/freeBusy`, {
    method: "POST",
    body: JSON.stringify({
      timeMin: timeMin.toISOString(),
      timeMax: timeMax.toISOString(),
      items: ids.map((id) => ({ id })),
    }),
  });
  const busy: { start: number; end: number }[] = [];
  for (const cal of Object.values(d.calendars ?? {})) {
    for (const b of cal.busy ?? []) busy.push({ start: Date.parse(b.start), end: Date.parse(b.end) });
  }
  return busy.sort((a, b) => a.start - b.start);
}

/* ───────────── Gmail ───────────── */

export type MailItem = {
  id: string;
  threadId: string;
  from: string;
  fromEmail: string;
  subject: string;
  date: string;
  snippet: string;
  messageId: string;
  unread: boolean;
};

type GmailMessage = {
  id: string;
  threadId: string;
  snippet?: string;
  labelIds?: string[];
  payload?: { headers?: { name: string; value: string }[] };
};

function header(m: GmailMessage, name: string) {
  return m.payload?.headers?.find((h) => h.name.toLowerCase() === name.toLowerCase())?.value ?? "";
}

function decodeEntities(s: string) {
  return s
    .replace(/&#39;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">");
}

function toItem(m: GmailMessage): MailItem {
  const from = header(m, "From");
  const emailMatch = from.match(/<([^>]+)>/);
  return {
    id: m.id,
    threadId: m.threadId,
    from: from.replace(/<[^>]+>/, "").replace(/"/g, "").trim() || from,
    fromEmail: emailMatch?.[1] ?? from,
    subject: header(m, "Subject") || "(no subject)",
    date: header(m, "Date"),
    snippet: decodeEntities(m.snippet ?? ""),
    messageId: header(m, "Message-ID") || header(m, "Message-Id"),
    unread: m.labelIds?.includes("UNREAD") ?? false,
  };
}

export async function getMessage(token: string, id: string): Promise<MailItem> {
  const p = new URLSearchParams({ format: "metadata" });
  for (const h of ["From", "Subject", "Date", "Message-ID"]) p.append("metadataHeaders", h);
  return toItem(await g<GmailMessage>(token, `${GMAIL}/messages/${id}?${p}`));
}

export async function listInbox(token: string, max = 15): Promise<MailItem[]> {
  const p = new URLSearchParams({
    q: "in:inbox newer_than:7d -category:promotions -category:social",
    maxResults: String(max),
  });
  const list = await g<{ messages?: { id: string }[] }>(token, `${GMAIL}/messages?${p}`);
  return Promise.all((list.messages ?? []).map((m) => getMessage(token, m.id)));
}

function encodeHeader(v: string) {
  return /^[\x20-\x7e]*$/.test(v) ? v : `=?UTF-8?B?${Buffer.from(v).toString("base64")}?=`;
}

export async function createDraftReply(token: string, messageId: string, body: string) {
  const m = await getMessage(token, messageId);
  const subject = /^re:/i.test(m.subject) ? m.subject : `Re: ${m.subject}`;
  const headers = [
    `To: ${m.fromEmail}`,
    `Subject: ${encodeHeader(subject)}`,
    ...(m.messageId ? [`In-Reply-To: ${m.messageId}`, `References: ${m.messageId}`] : []),
    "Content-Type: text/plain; charset=UTF-8",
  ];
  const raw = [...headers, "", body].join("\r\n");
  return g<{ id: string }>(token, `${GMAIL}/drafts`, {
    method: "POST",
    body: JSON.stringify({ message: { raw: Buffer.from(raw).toString("base64url"), threadId: m.threadId } }),
  });
}

export async function archiveMessage(token: string, id: string) {
  await g(token, `${GMAIL}/messages/${id}/modify`, {
    method: "POST",
    body: JSON.stringify({ removeLabelIds: ["INBOX"] }),
  });
}

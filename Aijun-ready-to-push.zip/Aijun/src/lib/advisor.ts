import type { CalEvent } from "./google";

export type Verdict = "in_person" | "consider_online" | "take_online" | "online" | "no_location";

export type Advice = {
  verdict: Verdict;
  reason: string;
  travelMinutes?: number;
  distanceKm?: number;
  leaveBy?: string;
  origin?: string;
};

const VIDEO = /zoom\.us|meet\.google|teams\.microsoft|teams\.live|webex|whereby|skype/i;

export function isOnline(e: CalEvent) {
  return Boolean(
    e.hangoutLink ||
      e.conferenceData?.entryPoints?.some((p) => p.entryPointType === "video") ||
      VIDEO.test(e.location ?? "") ||
      VIDEO.test(e.description ?? ""),
  );
}

export function meetingLink(e: CalEvent): string | undefined {
  return (
    e.hangoutLink ||
    e.conferenceData?.entryPoints?.find((p) => p.entryPointType === "video")?.uri ||
    (e.location?.match(/https?:\/\/\S+/)?.[0] ?? undefined)
  );
}

export function physicalLocation(e: CalEvent): string | null {
  const loc = e.location?.trim();
  if (!loc || /^https?:\/\//i.test(loc) || VIDEO.test(loc)) return null;
  return loc;
}

/**
 * Jun's rule of thumb for "should you just do this online?"
 *  - Can't physically make it in time (travel + buffer > free time before) → take it online
 *  - Round trip is 1.5× the meeting or more → take it online
 *  - Round trip longer than the meeting, or 45+ minutes each way → consider online
 *  - Otherwise → go in person
 */
export function advise(input: {
  meetingMinutes: number;
  travelMinutes: number;
  gapMinutes: number;
  bufferMinutes: number;
}): { verdict: Verdict; reason: string } {
  const { meetingMinutes, travelMinutes, gapMinutes, bufferMinutes } = input;
  const roundTrip = travelMinutes * 2;
  if (travelMinutes + bufferMinutes > gapMinutes) {
    return {
      verdict: "take_online",
      reason: `You need ${travelMinutes + bufferMinutes} min to get there with buffer, but you only have ${Math.max(0, Math.round(gapMinutes))} min free before it.`,
    };
  }
  if (roundTrip >= meetingMinutes * 1.5) {
    return {
      verdict: "take_online",
      reason: `${roundTrip} min on the road for a ${meetingMinutes}-min meeting. Not worth it unless it's important face to face.`,
    };
  }
  if (roundTrip > meetingMinutes || travelMinutes >= 45) {
    return {
      verdict: "consider_online",
      reason: `${travelMinutes} min each way. Doable, but online would give you back ${roundTrip} min.`,
    };
  }
  return { verdict: "in_person", reason: `${travelMinutes} min away. Easy trip.` };
}

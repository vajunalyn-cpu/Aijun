"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { api, fmtDay } from "@/lib/client";
import { useApp } from "./AppContext";

type Block = { id: string; reason: string; startDate: string; endDate: string };

const REASONS = ["Out of office", "Personal day", "Travelling", "Deep work", "Holiday"];

function ymd(d: Date) {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function fmtRange(a: string, b: string) {
  const f = (s: string) => new Intl.DateTimeFormat(undefined, { weekday: "short", month: "short", day: "numeric" }).format(new Date(`${s}T12:00:00`));
  return a === b ? f(a) : `${f(a)} to ${f(b)}`;
}

export function AvailabilityView() {
  const { notify, refresh } = useApp();
  const [blocks, setBlocks] = useState<Block[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [reason, setReason] = useState(REASONS[0]);
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const d = await api<{ blocks: Block[] }>("/api/availability");
      setBlocks(d.blocks);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Couldn't load your blocked dates.");
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  // Six weeks, starting on the Monday of this week.
  const grid = useMemo(() => {
    const today = new Date();
    const first = new Date(today);
    first.setDate(today.getDate() - ((today.getDay() + 6) % 7));
    return Array.from({ length: 42 }, (_, i) => {
      const d = new Date(first);
      d.setDate(first.getDate() + i);
      return d;
    });
  }, []);
  const todayStr = ymd(new Date());

  const blockedOn = (day: string) => blocks?.find((b) => day >= b.startDate && day <= b.endDate);
  const selected = (day: string) => start && day >= start && day <= (end || start);

  function pick(day: string) {
    setFormError(null);
    if (!start || (start && end) || day < start) {
      setStart(day);
      setEnd("");
    } else {
      setEnd(day);
    }
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!start) return setFormError("Pick the first day you're unavailable.");
    if (end && end < start) return setFormError("The last day comes before the first day.");
    setBusy(true);
    try {
      await api("/api/availability", {
        method: "POST",
        body: JSON.stringify({ startDate: start, endDate: end || start, reason }),
      });
      notify({ tone: "jade", title: "Dates blocked", body: `${fmtRange(start, end || start)} now shows as busy.` });
      setStart("");
      setEnd("");
      load();
      refresh();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Couldn't block those dates.");
    } finally {
      setBusy(false);
    }
  }

  async function unblock(b: Block) {
    try {
      await api(`/api/availability?id=${encodeURIComponent(b.id)}`, { method: "DELETE" });
      notify({ tone: "jade", title: "Dates freed up", body: fmtRange(b.startDate, b.endDate) });
      load();
      refresh();
    } catch (err) {
      notify({ tone: "rose", title: "Couldn't unblock", body: err instanceof Error ? err.message : undefined });
    }
  }

  return (
    <div className="page">
      <h1 className="page__title">Availability</h1>
      <p className="page__lede">Days you block show as busy in Google Calendar, so nobody can book you on them.</p>

      <div className="avail">
        <form className="avail__form" onSubmit={submit} noValidate>
          <div className="cal" role="group" aria-label="Pick days to block">
            {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((d) => (
              <span key={d} className="cal__dow" aria-hidden="true">
                {d}
              </span>
            ))}
            {grid.map((d) => {
              const day = ymd(d);
              const blocked = blockedOn(day);
              const isPast = day < todayStr;
              return (
                <button
                  key={day}
                  type="button"
                  className="cal__day"
                  data-blocked={blocked ? true : undefined}
                  data-selected={selected(day) || undefined}
                  data-today={day === todayStr || undefined}
                  disabled={isPast}
                  aria-pressed={Boolean(selected(day))}
                  aria-label={`${fmtDay(`${day}T12:00:00`)}${blocked ? `, blocked: ${blocked.reason}` : ""}`}
                  onClick={() => pick(day)}
                >
                  {d.getDate()}
                </button>
              );
            })}
          </div>

          <div className="field-row">
            <label className="field">
              <span>First day</span>
              <input className="input" type="date" value={start} min={todayStr} onChange={(e) => setStart(e.target.value)} required />
            </label>
            <label className="field">
              <span>Last day</span>
              <input className="input" type="date" value={end} min={start || todayStr} onChange={(e) => setEnd(e.target.value)} />
            </label>
          </div>
          <label className="field">
            <span>Reason (shows on your calendar)</span>
            <input className="input" list="reasons" value={reason} onChange={(e) => setReason(e.target.value)} />
            <datalist id="reasons">
              {REASONS.map((r) => (
                <option key={r} value={r} />
              ))}
            </datalist>
          </label>
          {formError && (
            <p className="form-error" role="alert">
              {formError}
            </p>
          )}
          <button type="submit" className="btn btn--primary" disabled={busy}>
            {busy ? "Blocking…" : start ? `Block ${fmtRange(start, end || start)}` : "Block these dates"}
          </button>
        </form>

        <section className="avail__list" aria-labelledby="blocked-heading">
          <h2 id="blocked-heading" className="section-title">
            Already blocked
          </h2>
          {error && (
            <p className="form-error" role="alert">
              {error}
            </p>
          )}
          {blocks === null && !error && <p className="muted">Loading…</p>}
          {blocks?.length === 0 && <p className="muted">No blocked dates. Pick days on the calendar to protect them.</p>}
          <ul className="blocks">
            {blocks?.map((b) => (
              <li key={b.id}>
                <div>
                  <p className="blocks__when">{fmtRange(b.startDate, b.endDate)}</p>
                  <p className="muted">{b.reason}</p>
                </div>
                <button type="button" className="btn btn--small btn--quiet" onClick={() => unblock(b)}>
                  Unblock
                </button>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  );
}

"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";
import { AppProvider, useApp } from "./AppContext";
import { JunPanel } from "./JunPanel";
import { MoveDialog } from "./MoveDialog";
import { SettingsDialog } from "./SettingsDialog";
import { Toasts } from "./Toasts";

const NAV = [
  { href: "/", label: "Today" },
  { href: "/inbox", label: "Inbox" },
  { href: "/availability", label: "Availability" },
];

function Header() {
  const pathname = usePathname();
  const { user, setSettingsOpen } = useApp();
  const initial = (user.name ?? user.email ?? "?").charAt(0).toUpperCase();
  return (
    <header className="topbar">
      <Link href="/" className="wordmark" aria-label="Jun, home">
        jun
      </Link>
      <nav aria-label="Main">
        <ul className="nav">
          {NAV.map((n) => (
            <li key={n.href}>
              <Link href={n.href} aria-current={pathname === n.href ? "page" : undefined}>
                {n.label}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      <button type="button" className="avatar" onClick={() => setSettingsOpen(true)} aria-label="Settings">
        {user.image ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={user.image} alt="" width={32} height={32} referrerPolicy="no-referrer" />
        ) : (
          <span>{initial}</span>
        )}
      </button>
    </header>
  );
}

export function AppShell({ user, children }: { user: { name?: string | null; email?: string | null; image?: string | null }; children: ReactNode }) {
  return (
    <AppProvider user={user}>
      <a href="#main" className="skip">
        Skip to content
      </a>
      <div className="shell">
        <Header />
        <main id="main" className="main">
          {children}
        </main>
        <JunPanel />
      </div>
      <MoveDialog />
      <SettingsDialog />
      <Toasts />
    </AppProvider>
  );
}

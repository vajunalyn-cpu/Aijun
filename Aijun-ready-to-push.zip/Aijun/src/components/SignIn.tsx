"use client";

import { signIn } from "next-auth/react";
import { JunOrb } from "./JunPanel";

export function SignIn() {
  return (
    <main className="signin">
      <div className="signin__inner">
        <JunOrb state="idle" />
        <h1 className="signin__title">I&rsquo;m Jun. Hand me your calendar and inbox, and I&rsquo;ll keep your days honest.</h1>
        <p className="signin__lede">
          I block the days you&rsquo;re out, tell you when to leave, say when a meeting should just be a call, and sort the mail
          that actually needs you. Talk to me or type.
        </p>
        <button type="button" className="btn btn--primary btn--large" onClick={() => signIn("google", { callbackUrl: "/" })}>
          Continue with Google
        </button>
        <p className="signin__fine">
          Jun reads and updates your Google Calendar and Gmail only when you use the app. Emails are saved as drafts, never sent
          on their own.
        </p>
      </div>
    </main>
  );
}

"use client";

import { useEffect, useState } from "react";
import { api, dayKey, fmtDay, fmtTime, minutesBetween, VERDICT_LABEL, type DayEvent } from "@/lib/client";
import { useApp } from "./AppContext";
import { ConfirmDialog } from "./Dialog";

function useNow(intervalMs = 60000) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  return now;
}

function RailItem({ e, tz, onOnline }: { e: DayEvent; tz?: string; onOnline: (e: DayEvent) => void }) {
  const { setMoving, sendToJun } = useApp();
  const a = e.advice;
  const past = Date.parse(e.end) < Date.now();
  const length = minutesBetween(e.start, e.end);
  const showTravel = !past && a?.travelMinutes && a.verdict !== "online";
  // Travel band height grows with the trip so long commutes literally take up room on your day.
  const bandSize = showTravel ? Math.min(140, 28 + (a!.travelMinutes ?? 0)) : 0;

  return (
    <li className="rail__item" data-verdict={a?.verdict ?? "none"} data-past={past || undefined}>
      {showTravel && (
        <div className="travel" style={{ minHeight: `${bandSize}px` }}>
          <p>
            <strong>Leave by {fmtTime(a!.leaveBy!, tz)}</strong>
            <span>
              {a!.travelMinutes} min{a!.distanceKm ? `, ${a!.distanceKm} km` : ""} from {a!.origin}
            </span>
          </p>
        </div>
      )}
      <div className="rail__row">
        <p className="rail__time">
          <time dateTime={e.start}>{fmtTime(e.start, tz)}</time>
          <span>{length >= 60 ? `${Math.floor(length / 60)}h${length % 60 ? ` ${length % 60}m` : ""}` : `${length}m`}</span>
        </p>
        <div className="rail__body">
          <h3 className="rail__title">{e.title}</h3>
          <p className="rail__where">
            {e.online ? "Video call" : e.location ?? "No location"}
            {e.attendees > 0 && `, with ${e.attendees} ${e.attendees === 1 ? "other" : "others"}`}
          </p>
          {a && !past && a.verdict !== "online" && (
            <p className="verdict">
              <span className="verdict__tag">{VERDICT_LABEL[a.verdict]}</span> {a.reason}
            </p>
          )}
          {!past && (
            <div className="rail__actions">
              {e.meetLink && (
                <a className="btn btn--small btn--primary" href={e.meetLink} target="_blank" rel="noreferrer">
                  Join call
                </a>
              )}
              {!e.online && e.location && e.organizerSelf && (
                <button
                  type="button"
                  className={`btn btn--small${a?.verdict === "take_online" ? " btn--primary" : ""}`}
                  onClick={() => onOnline(e)}
                >
                  Switch to online
                </button>
              )}
              {e.directionsUrl && !e.online && (
                <a className="btn btn--small" href={e.directionsUrl} target="_blank" rel="noreferrer">
                  Directions
                </a>
              )}
              {e.organizerSelf ? (
                <button type="button" className="btn btn--small" onClick={() => setMoving(e)}>
                  Move
                </button>
              ) : (
                <button
                  type="button"
                  className="btn btn--small"
                  onClick={() =>
                    sendToJun(
                      `I'm not the organizer of "${e.title}" at ${fmtTime(e.start, tz)}. Write me a short, polite message asking to move it and suggest two times that work for me.`,
                    )
                  }
                >
                  Ask to move
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </li>
  );
}

export function TodayView() {
  const { schedule, settings, setSettingsOpen, voice, refresh, notify } = useApp();
  const [onlineTarget, setOnlineTarget] = useState<DayEvent | null>(null);
  const [busy, setBusy] = useState(false);
  const now = useNow();
  const tz = schedule.timeZone;

  const days = new Map<string, DayEvent[]>();
  for (const e of schedule.events) {
    const k = e.allDay ? e.start.slice(0, 10) : dayKey(e.start, tz);
    if (!days.has(k)) days.set(k, []);
    days.get(k)!.push(e);
  }
  const todayKey = dayKey(now, tz);
  const tomorrowKey = dayKey(now + 86400000, tz);
  const keys = [...days.keys()].filter((k) => k >= todayKey).sort().slice(0, 3);
  if (!keys.includes(todayKey)) keys.unshift(todayKey);

  async function switchOnline() {
    if (!onlineTarget) return;
    setBusy(true);
    try {
      await api(`/api/meetings/${encodeURIComponent(onlineTarget.id)}`, {
        method: "PATCH",
        body: JSON.stringify({ action: "online" }),
      });
      notify({ tone: "jade", title: `${onlineTarget.title} is now on Google Meet`, body: "Attendees got the new link." });
      setOnlineTarget(null);
      refresh();
    } catch (e) {
      notify({ tone: "rose", title: "Couldn't switch it online", body: e instanceof Error ? e.message : undefined });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="today">
      <section className="brief" aria-labelledby="brief-heading">
        <h1 id="brief-heading" className="sr-only">
          Today
        </h1>
        <p className="brief__date">{fmtDay(new Date(now).toISOString(), tz)}</p>
        {schedule.loading ? (
          <p className="brief__text brief__text--loading">Reading your calendar…</p>
        ) : schedule.error ? (
          <div className="notice notice--rose" role="alert">
            <p>{schedule.error}</p>
            <button type="button" className="btn btn--small" onClick={refresh}>
              Try again
            </button>
          </div>
        ) : (
          <>
            <p className="brief__text">{schedule.brief}</p>
            <button
              type="button"
              className="btn btn--quiet brief__play"
              onClick={() => (voice.state === "speaking" ? voice.stopSpeaking() : voice.speak(schedule.brief))}
            >
              {voice.state === "speaking" ? "Stop" : "Hear it from Jun"}
            </button>
          </>
        )}
      </section>

      {!settings.homeBase && !schedule.loading && (
        <div className="notice">
          <p>Add your home base so Jun can time your trips and tell you when to leave.</p>
          <button type="button" className="btn btn--small" onClick={() => setSettingsOpen(true)}>
            Add home base
          </button>
        </div>
      )}
      {!schedule.mapsReady && (
        <div className="notice">
          <p>Travel times are off. Add GOOGLE_MAPS_API_KEY to your environment to turn them on.</p>
        </div>
      )}

      {!schedule.loading &&
        !schedule.error &&
        keys.map((k) => {
          const list = (days.get(k) ?? []).filter((e) => !e.allDay || e.isBlock);
          const allDay = (days.get(k) ?? []).filter((e) => e.allDay && !e.isBlock);
          const label =
            k === todayKey ? "Today" : k === tomorrowKey ? "Tomorrow" : fmtDay(`${k}T12:00:00`).split(",")[0];
          const nowIndex = k === todayKey ? list.findIndex((e) => !e.allDay && Date.parse(e.start) > now) : -1;
          return (
            <section key={k} className="day" aria-labelledby={`day-${k}`}>
              <h2 id={`day-${k}`} className="day__title">
                {label} <span>{fmtDay(`${k}T12:00:00`)}</span>
              </h2>
              {allDay.length > 0 && <p className="day__allday">All day: {allDay.map((e) => e.title).join(", ")}</p>}
              {list.length === 0 ? (
                <p className="day__empty">Nothing booked. Ask Jun to protect it or plan it.</p>
              ) : (
                <ol className="rail">
                  {list.map((e, idx) =>
                    e.isBlock ? (
                      <li key={e.id} className="rail__block">
                        Unavailable: {e.title.replace(/^Unavailable:\s*/, "")}
                      </li>
                    ) : (
                      <RailNowWrapper key={e.id} showNow={idx === nowIndex} now={now} tz={tz}>
                        <RailItem e={e} tz={tz} onOnline={setOnlineTarget} />
                      </RailNowWrapper>
                    ),
                  )}
                </ol>
              )}
            </section>
          );
        })}

      <ConfirmDialog
        open={Boolean(onlineTarget)}
        title={onlineTarget ? `Switch ${onlineTarget.title} to online?` : "Switch to online?"}
        body={
          <p>
            Jun adds a Google Meet link, clears the address and sends everyone the updated invite.
            {onlineTarget?.advice?.reason ? ` ${onlineTarget.advice.reason}` : ""}
          </p>
        }
        confirmLabel="Switch to online"
        cancelLabel="Keep in person"
        busy={busy}
        onConfirm={switchOnline}
        onClose={() => setOnlineTarget(null)}
      />
    </div>
  );
}

function RailNowWrapper({ showNow, now, tz, children }: { showNow: boolean; now: number; tz?: string; children: React.ReactNode }) {
  return (
    <>
      {showNow && (
        <li className="rail__now" aria-label={`Now, ${fmtTime(new Date(now).toISOString(), tz)}`}>
          <span>Now {fmtTime(new Date(now).toISOString(), tz)}</span>
        </li>
      )}
      {children}
    </>
  );
}

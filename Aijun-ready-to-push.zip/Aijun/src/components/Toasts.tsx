"use client";

import { useEffect, useRef, useState } from "react";
import { useApp } from "./AppContext";

/** A single top-layer stack (popover="manual") so alerts stay put while you keep working. */
export function Toasts() {
  const { toasts, dismiss } = useApp();
  const ref = useRef<HTMLElement>(null);
  const [supported, setSupported] = useState(true);

  useEffect(() => {
    setSupported("popover" in HTMLElement.prototype);
  }, []);

  useEffect(() => {
    const el = ref.current;
    if (!el || !supported) return;
    const open = el.matches(":popover-open");
    try {
      if (toasts.length && !open) el.showPopover();
      if (!toasts.length && open) el.hidePopover();
    } catch {
      /* already in the requested state */
    }
  }, [toasts.length, supported]);

  if (!supported && !toasts.length) return null;

  return (
    <section ref={ref} popover={supported ? "manual" : undefined} className="toast-stack" aria-label="Alerts from Jun">
      {toasts.map((t) => (
        <div key={t.id} className={`toast toast--${t.tone}`} role="status">
          <div className="toast__text">
            <p className="toast__title">{t.title}</p>
            {t.body && <p className="toast__body">{t.body}</p>}
          </div>
          <div className="toast__actions">
            {t.actions?.map((a) =>
              a.href ? (
                <a key={a.label} className="btn btn--small" href={a.href} target="_blank" rel="noreferrer">
                  {a.label}
                </a>
              ) : (
                <button
                  key={a.label}
                  type="button"
                  className="btn btn--small"
                  onClick={() => {
                    a.onClick?.();
                    dismiss(t.id);
                  }}
                >
                  {a.label}
                </button>
              ),
            )}
            <button type="button" className="btn btn--small btn--quiet" onClick={() => dismiss(t.id)}>
              Dismiss
            </button>
          </div>
        </div>
      ))}
    </section>
  );
}

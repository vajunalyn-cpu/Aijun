"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { api } from "@/lib/client";
import { useApp } from "./AppContext";

type Turn = { role: "user" | "assistant"; content: string };

const STARTERS = [
  "What does my day look like?",
  "Find a quiet lunch spot near my next meeting",
  "Block next Friday, I'm out",
  "Anything urgent in my inbox?",
];

export function JunOrb({ state }: { state: "idle" | "listening" | "thinking" | "speaking" }) {
  return (
    <span className="orb" data-state={state} aria-hidden="true">
      <span className="orb__ring" />
      <span className="orb__core" />
    </span>
  );
}

export function JunPanel() {
  const { settings, schedule, voice, refresh, junInbox, clearJunInbox, user } = useApp();
  const [turns, setTurns] = useState<Turn[]>([]);
  const [text, setText] = useState("");
  const [thinking, setThinking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const logRef = useRef<HTMLOListElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const status = voice.state === "listening" ? "listening" : thinking ? "thinking" : voice.state === "speaking" ? "speaking" : "idle";
  const statusText = {
    listening: "Listening…",
    thinking: "On it…",
    speaking: "Speaking",
    idle: "Ready when you are",
  }[status];

  useEffect(() => {
    logRef.current?.lastElementChild?.scrollIntoView({ block: "end", behavior: "smooth" });
  }, [turns, thinking]);

  const send = useCallback(
    async (message: string) => {
      const content = message.trim();
      if (!content || thinking) return;
      setError(null);
      setText("");
      setOpen(true);
      const history: Turn[] = [...turns, { role: "user", content }];
      setTurns(history);
      setThinking(true);
      try {
        const { reply, changed } = await api<{ reply: string; changed: boolean }>("/api/jun", {
          method: "POST",
          body: JSON.stringify({
            history,
            prefs: { origin: settings.homeBase, buffer: settings.bufferMinutes, mode: settings.mode },
          }),
        });
        setTurns((t) => [...t, { role: "assistant", content: reply }]);
        if (changed) refresh();
        if (settings.speakReplies) voice.speak(reply);
      } catch (e) {
        setError(e instanceof Error ? e.message : "Jun couldn't answer. Try again.");
      } finally {
        setThinking(false);
      }
    },
    [turns, thinking, settings, refresh, voice],
  );

  useEffect(() => {
    if (junInbox) {
      send(junInbox);
      clearJunInbox();
    }
  }, [junInbox, send, clearJunInbox]);

  async function talk() {
    if (voice.state === "listening") return voice.stopListening();
    const heard = await voice.listen();
    if (heard) send(heard);
  }

  const first = user.name?.split(" ")[0];

  return (
    <aside className="jun" data-open={open} aria-label="Talk to Jun">
      <header className="jun__head">
        <JunOrb state={status} />
        <div className="jun__who">
          <p className="jun__name">Jun</p>
          <p className="jun__status" aria-live="polite">
            {statusText}
          </p>
        </div>
        <button
          type="button"
          className="btn btn--small btn--quiet jun__toggle"
          aria-expanded={open}
          onClick={() => setOpen((o) => !o)}
        >
          {open ? "Hide chat" : "Show chat"}
        </button>
        {voice.state === "speaking" && (
          <button type="button" className="btn btn--small btn--quiet" onClick={voice.stopSpeaking}>
            Stop talking
          </button>
        )}
      </header>

      <ol className="jun__log" ref={logRef} aria-live="polite">
        {turns.length === 0 && (
          <li className="msg msg--jun">
            <p>{schedule.brief || `Hi${first ? ` ${first}` : ""}, I'm Jun. Ask me anything about your day.`}</p>
          </li>
        )}
        {turns.map((t, i) => (
          <li key={i} className={`msg ${t.role === "user" ? "msg--you" : "msg--jun"}`}>
            <span className="sr-only">{t.role === "user" ? "You said:" : "Jun said:"}</span>
            <p>{t.content}</p>
          </li>
        ))}
        {thinking && (
          <li className="msg msg--jun msg--thinking">
            <p>Checking…</p>
          </li>
        )}
      </ol>

      {turns.length === 0 && (
        <div className="jun__starters">
          {STARTERS.map((s) => (
            <button key={s} type="button" className="chip" onClick={() => send(s)}>
              {s}
            </button>
          ))}
        </div>
      )}

      {error && (
        <p className="form-error jun__error" role="alert">
          {error}
        </p>
      )}

      <form
        className="jun__form"
        onSubmit={(e) => {
          e.preventDefault();
          send(text);
        }}
      >
        <label className="sr-only" htmlFor="jun-input">
          Message Jun
        </label>
        <textarea
          id="jun-input"
          ref={inputRef}
          className="jun__input"
          rows={1}
          value={voice.state === "listening" ? voice.interim : text}
          placeholder={voice.state === "listening" ? "Listening…" : "Tell Jun what you need"}
          onChange={(e) => setText(e.target.value)}
          onFocus={() => setOpen(true)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
              e.preventDefault();
              send(text);
            }
          }}
          enterKeyHint="send"
        />
        {voice.canListen && (
          <button
            type="button"
            className="mic"
            data-active={voice.state === "listening"}
            aria-pressed={voice.state === "listening"}
            aria-label={voice.state === "listening" ? "Stop listening" : "Talk to Jun"}
            onClick={talk}
          >
            <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true">
              <path
                d="M12 3a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3Zm-7 9a7 7 0 0 0 14 0M12 19v2"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
              />
            </svg>
          </button>
        )}
        <button type="submit" className="btn btn--primary jun__send" disabled={!text.trim() || thinking}>
          Send
        </button>
      </form>
    </aside>
  );
}

"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { api, DEFAULT_SETTINGS, fmtTime, prefsQuery, type DayEvent, type Settings } from "@/lib/client";
import { useStoredState } from "@/hooks/useStoredState";
import { useVoice } from "@/hooks/useVoice";

export type Toast = {
  id: string;
  title: string;
  body?: string;
  tone: "jade" | "marigold" | "rose";
  actions?: { label: string; href?: string; onClick?: () => void }[];
};

type Schedule = {
  events: DayEvent[];
  brief: string;
  timeZone?: string;
  mapsReady: boolean;
  loading: boolean;
  error: string | null;
};

type Ctx = {
  user: { name?: string | null; email?: string | null; image?: string | null };
  settings: Settings;
  setSettings: (s: Settings) => void;
  settingsLoaded: boolean;
  schedule: Schedule;
  refresh: () => Promise<void>;
  toasts: Toast[];
  notify: (t: Omit<Toast, "id">) => void;
  dismiss: (id: string) => void;
  voice: ReturnType<typeof useVoice>;
  moving: DayEvent | null;
  setMoving: (e: DayEvent | null) => void;
  settingsOpen: boolean;
  setSettingsOpen: (o: boolean) => void;
  junInbox: string | null;
  sendToJun: (text: string) => void;
  clearJunInbox: () => void;
};

const AppCtx = createContext<Ctx | null>(null);

export function useApp() {
  const c = useContext(AppCtx);
  if (!c) throw new Error("useApp must be used inside AppProvider");
  return c;
}

const FIRED_KEY = "jun:fired";

export function AppProvider({ user, children }: { user: Ctx["user"]; children: ReactNode }) {
  const [settings, setSettings, settingsLoaded] = useStoredState<Settings>("jun:settings", DEFAULT_SETTINGS);
  const [schedule, setSchedule] = useState<Schedule>({
    events: [],
    brief: "",
    mapsReady: true,
    loading: true,
    error: null,
  });
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [moving, setMoving] = useState<DayEvent | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [junInbox, setJunInbox] = useState<string | null>(null);
  const voice = useVoice(settings.voiceLang);

  const notify = useCallback((t: Omit<Toast, "id">) => {
    const id = Math.random().toString(36).slice(2);
    setToasts((prev) => [...prev.slice(-3), { ...t, id }]);
    if (t.tone !== "rose") setTimeout(() => setToasts((p) => p.filter((x) => x.id !== id)), 12000);
  }, []);
  const dismiss = useCallback((id: string) => setToasts((p) => p.filter((t) => t.id !== id)), []);

  const refresh = useCallback(async () => {
    if (!settingsLoaded) return;
    try {
      const q = prefsQuery(settings);
      q.set("days", "3");
      const d = await api<{ events: DayEvent[]; brief: string; timeZone: string; mapsReady: boolean }>(
        `/api/schedule?${q}`,
      );
      setSchedule({ ...d, loading: false, error: null });
    } catch (err) {
      setSchedule((s) => ({ ...s, loading: false, error: err instanceof Error ? err.message : "Couldn't load your calendar." }));
    }
  }, [settings, settingsLoaded]);

  useEffect(() => {
    refresh();
    const t = setInterval(refresh, 2 * 60 * 1000);
    const onFocus = () => document.visibilityState === "visible" && refresh();
    document.addEventListener("visibilitychange", onFocus);
    return () => {
      clearInterval(t);
      document.removeEventListener("visibilitychange", onFocus);
    };
  }, [refresh]);

  /* ───── Reminders: leave-by alerts for in-person, heads-up for online ───── */
  const eventsRef = useRef(schedule.events);
  eventsRef.current = schedule.events;
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  const speakRef = useRef(voice.speak);
  speakRef.current = voice.speak;

  useEffect(() => {
    const check = () => {
      const now = Date.now();
      let fired: string[] = [];
      try {
        fired = JSON.parse(localStorage.getItem(FIRED_KEY) ?? "[]");
      } catch {
        fired = [];
      }
      const s = settingsRef.current;
      const tz = schedule.timeZone;
      const alerts: { key: string; at: number; toast: Omit<Toast, "id">; speech: string }[] = [];

      for (const e of eventsRef.current) {
        if (e.allDay || e.isBlock) continue;
        const start = Date.parse(e.start);
        if (start < now - 60000) continue;
        const a = e.advice;
        if (a?.leaveBy && a.verdict !== "online") {
          const leave = Date.parse(a.leaveBy);
          alerts.push({
            key: `${e.id}:${e.start}:prep`,
            at: leave - s.alertMinutes * 60000,
            toast: {
              tone: a.verdict === "take_online" ? "rose" : "marigold",
              title: `Leave by ${fmtTime(a.leaveBy, tz)} for ${e.title}`,
              body: `${a.travelMinutes} min trip. ${a.verdict === "take_online" || a.verdict === "consider_online" ? a.reason : ""}`.trim(),
              actions: [
                ...(e.directionsUrl ? [{ label: "Directions", href: e.directionsUrl }] : []),
                { label: "Move it", onClick: () => setMoving(e) },
              ],
            },
            speech: `Heads up. Leave by ${fmtTime(a.leaveBy, tz)} for ${e.title}. It's a ${a.travelMinutes} minute trip.`,
          });
          alerts.push({
            key: `${e.id}:${e.start}:go`,
            at: leave,
            toast: {
              tone: "rose",
              title: `Time to go: ${e.title}`,
              body: `Starts at ${fmtTime(e.start, tz)}.`,
              actions: e.directionsUrl ? [{ label: "Directions", href: e.directionsUrl }] : [],
            },
            speech: `Time to go. ${e.title} starts at ${fmtTime(e.start, tz)}.`,
          });
        } else {
          alerts.push({
            key: `${e.id}:${e.start}:soon`,
            at: start - s.alertMinutes * 60000,
            toast: {
              tone: "jade",
              title: `${e.title} at ${fmtTime(e.start, tz)}`,
              body: e.meetLink ? "Your link is ready." : undefined,
              actions: [
                ...(e.meetLink ? [{ label: "Join", href: e.meetLink }] : []),
                { label: "Move it", onClick: () => setMoving(e) },
              ],
            },
            speech: `${e.title} starts in ${s.alertMinutes} minutes.`,
          });
        }
      }

      const due = alerts.filter((a) => a.at <= now && a.at > now - 15 * 60000 && !fired.includes(a.key));
      for (const a of due) {
        notify(a.toast);
        if (s.speakReplies) speakRef.current(a.speech);
        if ("Notification" in window && Notification.permission === "granted" && document.visibilityState !== "visible") {
          new Notification(`Jun: ${a.toast.title}`, { body: a.toast.body, tag: a.key, icon: "/icon.svg" });
        }
        fired.push(a.key);
      }
      if (due.length) {
        try {
          localStorage.setItem(FIRED_KEY, JSON.stringify(fired.slice(-200)));
        } catch {
          /* ignore */
        }
      }
    };
    check();
    const t = setInterval(check, 30000);
    return () => clearInterval(t);
  }, [notify, schedule.timeZone]);

  const value = useMemo<Ctx>(
    () => ({
      user,
      settings,
      setSettings,
      settingsLoaded,
      schedule,
      refresh,
      toasts,
      notify,
      dismiss,
      voice,
      moving,
      setMoving,
      settingsOpen,
      setSettingsOpen,
      junInbox,
      sendToJun: (text: string) => setJunInbox(text),
      clearJunInbox: () => setJunInbox(null),
    }),
    [user, settings, setSettings, settingsLoaded, schedule, refresh, toasts, notify, dismiss, voice, moving, settingsOpen, junInbox],
  );

  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}

"use client";

import { useCallback, useEffect, useRef, useState } from "react";

type Recognition = {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onresult: ((e: { resultIndex: number; results: ArrayLike<ArrayLike<{ transcript: string }> & { isFinal: boolean }> }) => void) | null;
  onend: (() => void) | null;
  onerror: ((e: { error: string }) => void) | null;
};

declare global {
  interface Window {
    SpeechRecognition?: new () => Recognition;
    webkitSpeechRecognition?: new () => Recognition;
  }
}

export type VoiceState = "idle" | "listening" | "speaking";

/** Strips markdown and symbols so speech sounds natural. */
function speakable(text: string) {
  return text
    .replace(/https?:\/\/\S+/g, "the link")
    .replace(/[*_#`>|~]/g, "")
    .replace(/^\s*[-•]\s+/gm, "")
    .replace(/\s+/g, " ")
    .trim();
}

const PREFERRED_VOICES = [
  "Google UK English Female",
  "Microsoft Aria",
  "Microsoft Jenny",
  "Samantha",
  "Karen",
  "Moira",
  "Tessa",
  "Microsoft Zira",
  "Google US English",
];

export function useVoice(lang: string) {
  const [state, setState] = useState<VoiceState>("idle");
  const [interim, setInterim] = useState("");
  const [canListen, setCanListen] = useState(false);
  const [premium, setPremium] = useState(false);
  const recRef = useRef<Recognition | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    setCanListen(Boolean(window.SpeechRecognition || window.webkitSpeechRecognition));
    fetch("/api/voice")
      .then((r) => r.json())
      .then((d) => setPremium(Boolean(d.premium)))
      .catch(() => setPremium(false));
    // Some browsers load voices lazily.
    window.speechSynthesis?.getVoices();
  }, []);

  const stopSpeaking = useCallback(() => {
    audioRef.current?.pause();
    audioRef.current = null;
    window.speechSynthesis?.cancel();
    setState((s) => (s === "speaking" ? "idle" : s));
  }, []);

  const speakWithBrowser = useCallback(
    (text: string) =>
      new Promise<void>((resolve) => {
        const synth = window.speechSynthesis;
        if (!synth) return resolve();
        const u = new SpeechSynthesisUtterance(text);
        const voices = synth.getVoices();
        const voice =
          PREFERRED_VOICES.map((n) => voices.find((v) => v.name.includes(n))).find(Boolean) ??
          voices.find((v) => v.lang.startsWith(lang.slice(0, 2)));
        if (voice) u.voice = voice;
        u.lang = voice?.lang ?? lang;
        u.rate = 1.03; // a touch brisk: commanding
        u.pitch = 1.08; // a touch bright: friendly
        u.onend = () => resolve();
        u.onerror = () => resolve();
        synth.cancel();
        synth.speak(u);
      }),
    [lang],
  );

  const speak = useCallback(
    async (raw: string) => {
      const text = speakable(raw);
      if (!text) return;
      stopSpeaking();
      setState("speaking");
      try {
        if (premium) {
          const res = await fetch("/api/voice", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ text }),
          });
          if (res.ok) {
            const url = URL.createObjectURL(await res.blob());
            const audio = new Audio(url);
            audioRef.current = audio;
            await new Promise<void>((resolve) => {
              audio.onended = () => resolve();
              audio.onerror = () => resolve();
              audio.play().catch(() => resolve());
            });
            URL.revokeObjectURL(url);
            return;
          }
        }
        await speakWithBrowser(text);
      } finally {
        setState((s) => (s === "speaking" ? "idle" : s));
      }
    },
    [premium, speakWithBrowser, stopSpeaking],
  );

  /** Listens once and resolves with what the user said (empty string if nothing). */
  const listen = useCallback((): Promise<string> => {
    const Ctor = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Ctor) return Promise.resolve("");
    stopSpeaking();
    recRef.current?.abort();
    return new Promise((resolve) => {
      const rec = new Ctor();
      recRef.current = rec;
      rec.lang = lang;
      rec.interimResults = true;
      rec.continuous = false;
      let finalText = "";
      rec.onresult = (e) => {
        let live = "";
        for (let i = e.resultIndex; i < e.results.length; i++) {
          const r = e.results[i];
          if (r.isFinal) finalText += r[0].transcript;
          else live += r[0].transcript;
        }
        setInterim(finalText + live);
      };
      rec.onerror = () => {
        /* onend follows */
      };
      rec.onend = () => {
        setState("idle");
        setInterim("");
        recRef.current = null;
        resolve(finalText.trim());
      };
      setState("listening");
      rec.start();
    });
  }, [lang, stopSpeaking]);

  const stopListening = useCallback(() => recRef.current?.stop(), []);

  return { state, interim, canListen, premium, speak, stopSpeaking, listen, stopListening };
}
